class Schedule < ActiveRecord::Base
  belongs_to :loan
end
