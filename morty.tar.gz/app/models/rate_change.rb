class RateChange < ActiveRecord::Base
  belongs_to :loan
end
