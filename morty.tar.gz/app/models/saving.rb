class Saving < ActiveRecord::Base
  belongs_to :advance
end
